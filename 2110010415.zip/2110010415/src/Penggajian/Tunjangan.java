/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Penggajian;

/**
 *
 * @author Fadhel Rajib
 */
public class Tunjangan {
    private String Tunjangan_id;
    private String Jabatan_id;
    private String Uang_Makan;
    private String Uang_Transport;
    private String Tunjangan_Kel;
   
    
    
    public Tunjangan(){}
    
    public Tunjangan(String a){
        setTunjangan_id(a);
    }
    
    public Tunjangan(String a, String b){
        setTunjangan_id(a);
        setJabatan_id(b);
    }
    
    public Tunjangan(String a, String b, String c){
        setTunjangan_id(a);
        setJabatan_id(b);
        setUang_Makan(c);
    }
    
    public Tunjangan(String a, String b, String c, String d){
        setTunjangan_id(a);
        setJabatan_id(b);
        setUang_Makan(c);
        setUang_Transport(d);
    }
     
    public Tunjangan(String a, String b, String c, String d, String e){
        setTunjangan_id(a);
        setJabatan_id(b);
        setUang_Makan(c);
        setUang_Transport(d);
        setTunjangan_Kel(e);
    }
    
    public void setTunjangan_id (String a){
        this.Tunjangan_id=a;
    }
    public String getTunjangan_id(){
        return this.Tunjangan_id;
    }
    
    public void setJabatan_id (String b){
        this.Jabatan_id=b;
    }
    public String getJabatan_id(){
        return this.Jabatan_id;
    }
    
    public void setUang_Makan (String c){
        this.Uang_Makan=c;
    }
    public String getUang_Makan(){
        return this.Uang_Makan;
    }

    public void setUang_Transport (String d){
        this.Uang_Transport=d;
    }
    public String getUang_Transport(){
        return this.Uang_Transport;
    }
    
    public void setTunjangan_Kel (String e){
        this.Tunjangan_Kel=e;
    }
    public String getTunjangan_Kel(){
        return this.Tunjangan_Kel;
    }
    
    public String dataTunjangan(){
        return getTunjangan_id()+getJabatan_id()+getUang_Makan()+getUang_Transport()+getTunjangan_Kel(); 
    }
    public String dataTunjangan(String a, String b, String c, String d, String e){
        setTunjangan_id(a);
        setJabatan_id(b);
        setUang_Makan(c);
        setUang_Transport(d);
        setTunjangan_Kel(e);
        
        return getTunjangan_id()+getJabatan_id()+getUang_Makan()+getUang_Transport()+getTunjangan_Kel();
    }
}
