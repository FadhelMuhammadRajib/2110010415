/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Penggajian;

/**
 *
 * @author Fadhel Rajib
 */
public class Karyawan {
    private String Karyawan_id;
    private String Jabatan_id;
    private String Nip;
    private String Nama_Karyawan;
    private String Nama_Bagian;
    private String Stand;
    
    
    public Karyawan(){}
    
    public Karyawan(String a){
        setKaryawan_id(a);
    }
    
    public Karyawan(String a, String b){
        setKaryawan_id(a);
        setJabatan_id(b);
    }
    
    public Karyawan(String a, String b, String c){
        setKaryawan_id(a);
        setJabatan_id(b);
        setNip(c);
    }
    
    public Karyawan(String a, String b, String c, String d){
        setKaryawan_id(a);
        setJabatan_id(b);
        setNip(c);
        setNama_Karyawan(d);
    }
     
    public Karyawan(String a, String b, String c, String d, String e){
        setKaryawan_id(a);
        setJabatan_id(b);
        setNip(c);
        setNama_Karyawan(d);
        setNama_Bagian(e);
    }
    
     public Karyawan(String a, String b, String c, String d, String e, String f){
        setKaryawan_id(a);
        setJabatan_id(b);
        setNip(c);
        setNama_Karyawan(d);
        setNama_Bagian(e);
        setStand(f);
    }
    
    public void setKaryawan_id (String a){
        this.Karyawan_id=a;
    }
    public String getKaryawan_id(){
        return this.Karyawan_id;
    }
    
    public void setJabatan_id (String b){
        this.Jabatan_id=b;
    }
    public String getJabatan_id(){
        return this.Jabatan_id;
    }
    
    public void setNip (String c){
        this.Nip=c;
    }
    public String getNip(){
        return this.Nip;
    }
    
    public void setNama_Karyawan (String d){
        this.Nama_Karyawan=d;
    }
    public String getNama_Karyawan(){
        return this.Nama_Karyawan;
    }
    
    public void setNama_Bagian (String e){
        this.Nama_Bagian=e;
    }
    public String getNama_Bagian(){
        return this.Nama_Bagian;
    }
    
    public void setStand (String f){
        this.Stand=f;
    }
    public String getStand(){
        return this.Stand;
    }
    
    public String dataKaryawan(){
        return getKaryawan_id()+getJabatan_id()+getNip()+getNama_Karyawan()+getNama_Bagian()+getStand(); 
    }
    public String dataKaryawan(String a,String b,String c,String d, String e,String f){
    setKaryawan_id(a);
    setJabatan_id(b);
    setNip(c);
    setNama_Karyawan(d);
    setNama_Bagian(e);
    setStand(f);
        
        return getKaryawan_id()+getJabatan_id()+getNip()+getNama_Karyawan()+getNama_Bagian()+getStand();
    }
}