/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Penggajian;

/**
 *
 * @author Fadhel Rajib
 */
public class Absen {
    private String Absen_id;
    private String Karyawan_id;
    private String Tgl_Masuk;
    private String Jam_Masuk;
    private String Jam_Keluar;
   
    
    
    public Absen(){}
    
    public Absen(String a){
        setAbsen_id(a);
    }
    
    public Absen(String a, String b){
        setAbsen_id(a);
        setKaryawan_id(b);
    }
    
    public Absen(String a, String b, String c){
        setAbsen_id(a);
        setKaryawan_id(b);
        setTgl_Masuk(c);
    }
    
    public Absen(String a, String b, String c, String d){
        setAbsen_id(a);
        setKaryawan_id(b);
        setTgl_Masuk(c);
        setJam_Masuk(d);
    }
     
    public Absen(String a, String b, String c, String d, String e){
        setAbsen_id(a);
        setKaryawan_id(b);
        setTgl_Masuk(c);
        setJam_Masuk(d);
        setJam_Keluar(e);
    }
    
    public void setAbsen_id (String a){
        this.Absen_id=a;
    }
    public String getAbsen_id(){
        return this.Absen_id;
    }
    
    public void setKaryawan_id (String b){
        this.Karyawan_id=b;
    }
    public String getKaryawan_id(){
        return this.Karyawan_id;
    }
    
    public void setTgl_Masuk (String c){
        this.Tgl_Masuk=c;
    }
    public String getTgl_Masuk(){
        return this.Tgl_Masuk;
    }

    public void setJam_Masuk (String d){
        this.Jam_Masuk=d;
    }
    public String getJam_Masuk(){
        return this.Jam_Masuk;
    }
    
    public void setJam_Keluar (String e){
        this.Jam_Keluar=e;
    }
    public String getJam_Keluar(){
        return this.Jam_Keluar;
    }
    
    public String dataAbsen(){
        return getAbsen_id()+getKaryawan_id()+getTgl_Masuk()+getJam_Masuk()+getJam_Keluar(); 
    }
    public String dataAbsen(String a,String b,String c,String d,String e){
        setAbsen_id(a);
        setKaryawan_id(b);
        setTgl_Masuk(c);
        setJam_Masuk(d);
        setJam_Keluar(e);
        
        return getAbsen_id()+getKaryawan_id()+getTgl_Masuk()+getJam_Masuk()+getJam_Keluar();
    }
}
