/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Penggajian;

/**
 *
 * @author Fadhel Rajib
 */
public class User {
    private String Id;
    private String Email;
    private String Username;
    private String Password;
    
    public User(){}
    
    public User(String a){
        setId(a);
    }
    
    public User(String a, String b){
        setId(a);
        setEmail(b);
    }
    
    public User(String a, String b, String c){
        setId(a);
        setEmail(b);
        setUsername(c);
    }
    
    public User(String a, String b, String c, String d){
        setId(a);
        setEmail(b);
        setUsername(c);
        setPassword(d);
    }
    
    
    public void setId (String a){
        this.Id=a;
    }
    public String getId(){
        return this.Id;
    }
    
     public void setEmail (String b){
        this.Email=b;
    }
    public String getEmail(){
        return this.Email;
    }
    
    public void setUsername (String c){
        this.Username=c;
    }
    public String getUsername(){
        return this.Username;
    }
    
    public void setPassword (String d){
        this.Password=d;
    }
    public String getPassword(){
        return this.Password;
    }
    
    public String dataUser(){
        return getId()+getEmail()+getUsername()+getPassword(); 
    }
    public String dataUser(String a,String b,String c, String d){
        setId(a);
        setEmail(b);
        setUsername(c);
        setPassword(d);
        
        return getId()+getEmail()+getUsername()+getPassword();
    }
}

