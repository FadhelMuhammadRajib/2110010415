/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Penggajian;

/**
 *
 * @author Fadhel Rajib
 */
public class GajiPokok {
    private String GajiPokok_id;
    private String Jabatan_id;
    private String Nominal;
   
    
    
    public GajiPokok(){}
    
    public GajiPokok(String a){
        setGajiPokok_id(a);
    }
    
    public GajiPokok(String a, String b){
        setGajiPokok_id(a);
        setJabatan_id(b);
    }
    
    public GajiPokok(String a, String b, String c){
        setGajiPokok_id(a);
        setJabatan_id(b);
        setNominal(c);
    }
    
    public void setGajiPokok_id (String a){
        this.GajiPokok_id=a;
    }
    public String getGajiPokok_id(){
        return this.GajiPokok_id;
    }
    
    public void setJabatan_id (String b){
        this.Jabatan_id=b;
    }
    public String getJabatan_id(){
        return this.Jabatan_id;
    }
    
    public void setNominal (String c){
        this.Nominal=c;
    }
    public String getNominal(){
        return this.Nominal;
    }

    public String dataGajiPokok(){
        return getGajiPokok_id()+getJabatan_id()+getNominal(); 
    }
    public String dataGajiPokok(String a, String b, String c){
        setGajiPokok_id(a);
        setJabatan_id(b);
        setNominal(c);
        
        return getGajiPokok_id()+getJabatan_id()+getNominal();
    }
}