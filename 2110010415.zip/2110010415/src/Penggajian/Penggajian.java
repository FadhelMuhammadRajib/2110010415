/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Penggajian;

/**
 *
 * @author Fadhel Rajib
 */
public class Penggajian {
    private String Penggajian_id;
    private String Karyawan_id;
    private String Bulan;
    private String Status_Pengambilan;
    private String Total;
   
    
    
    public Penggajian(){}
    
    public Penggajian(String a){
        setPenggajian_id(a);
    }
    
    public Penggajian(String a, String b){
        setPenggajian_id(a);
        setKaryawan_id(b);
    }
    
    public Penggajian(String a, String b, String c){
        setPenggajian_id(a);
        setKaryawan_id(b);
        setBulan(c);
    }
    
    public Penggajian(String a, String b, String c, String d){
        setPenggajian_id(a);
        setKaryawan_id(b);
        setBulan(c);
        setStatus_Pengambilan(d);
    }
     
    public Penggajian(String a, String b, String c, String d, String e){
        setPenggajian_id(a);
        setKaryawan_id(b);
        setBulan(c);
        setStatus_Pengambilan(d);
        setTotal(e);
    }
    
    public void setPenggajian_id (String a){
        this.Penggajian_id=a;
    }
    public String getPenggajian_id(){
        return this.Penggajian_id;
    }
    
    public void setKaryawan_id (String b){
        this.Karyawan_id=b;
    }
    public String getKaryawan_id(){
        return this.Karyawan_id;
    }
    
    public void setBulan (String c){
        this.Bulan=c;
    }
    public String getBulan(){
        return this.Bulan;
    }

    public void setStatus_Pengambilan (String d){
        this.Status_Pengambilan=d;
    }
    public String getStatus_Pengambilan(){
        return this.Status_Pengambilan;
    }
    
    public void setTotal (String e){
        this.Total=e;
    }
    public String getTotal(){
        return this.Total;
    }
    
    public String dataPenggajian(){
        return getPenggajian_id()+getKaryawan_id()+getBulan()+getStatus_Pengambilan()+getTotal(); 
    }
    public String dataPenggajian(String a,String b,String c,String d,String e){
        setPenggajian_id(a);
        setKaryawan_id(b);
        setBulan(c);
        setStatus_Pengambilan(d);
        setTotal(e);
        
        return getPenggajian_id()+getKaryawan_id()+getBulan()+getStatus_Pengambilan()+getTotal();
    }
}
