/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Penggajian;

/**
 *
 * @author Fadhel Rajib
 */
public class Jabatan {
    private String Jabatan_id;
    private String Nama_Jabatan;
   
    
    
    public Jabatan(){}
    
    public Jabatan(String a){
        setJabatan_id(a);
    }
    
    public Jabatan(String a, String b){
        setJabatan_id(a);
        setNama_Jabatan(b);
    }
    
    public void setJabatan_id (String a){
        this.Jabatan_id=a;
    }
    public String getJabatan_id(){
        return this.Jabatan_id;
    }
    
     public void setNama_Jabatan (String b){
        this.Nama_Jabatan=b;
    }
    public String getNama_Jabatan(){
        return this.Nama_Jabatan;
    }
    
    public String dataJabatan(){
        return getJabatan_id()+getNama_Jabatan(); 
    }
    public String dataJabatan(String a,String b){
        setJabatan_id(a);
        setNama_Jabatan(b);
        
        return getJabatan_id()+getNama_Jabatan();
    }
}
