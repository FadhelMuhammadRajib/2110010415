/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package FadhelMuhammadRajib;

import Penggajian.*;
/**
 *
 * @author Fadhel Rajib
 */
public class PenggajianKaryawan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    //Method Overload
    System.out.println("Method Overload");
    Absen objku = new Absen();
    System.out.println("Data Absen: " +objku.dataAbsen("015 ", "2110010415 ", "19 Mei 2023 ", "09:45 ", "11:15"));
    
    GajiPokok objku2 = new GajiPokok();
    System.out.println("Data GajiPokok: " +objku2.dataGajiPokok("5.000.000 ", "2110010415 ", "10.000.000 "));
    
    Jabatan objku3 = new Jabatan();
    System.out.println("Data Jabatan: " +objku3.dataJabatan("2110010415 ", "Direktur Perusahaan "));
    
    Karyawan objku4 = new Karyawan();
    System.out.println("Data Karyawan: " +objku4.dataKaryawan("523821188 ", "Administrasi ", "2110010898 ", "Jamet ", "Pergudangan ", "Minuman "));
    
    Penggajian objku5 = new Penggajian();
    System.out.println("Data Penggajian: " +objku5.dataPenggajian("005 ", "523821188 ", "Juni ", "Sudah ", "5.000.000 "));
    
    Tunjangan objku6 = new Tunjangan();
    System.out.println("Data Tunjangan : " +objku6.dataTunjangan("006 ", "523821188 ", "1.000.000 ", "2.000.000 ", "5.000.000 "));
    
    User objku7 = new User();
    System.out.println("Data User : " +objku7.dataUser("2110010415 ", "fadhelanjay@gmail.com ", "Fadhel Rajib ","Anjay123 "));   
    }      
}
